# File content transformation

from pdfminer.high_level import extract_text
import docx2txt
import os
import unidecode

# content cleaning imports

import re
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer

# database and data container

import mysql.connector as mysqlc
import pandas as pd

# Machine learning and JD comparison
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, chi2

# comparison with JD
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# constants
CV_FOLDER: str = "res\\CV"
JD_FOLDER: str = "res\\JD"
CV_CLASSE = ["NON TRAITE", "BON", "MOYEN", "PAS BON"]

try:
    database = mysqlc.connect(
        host="devbdd.iutmetz.univ-lorraine.fr",
        port="3306",
        user="marsal15u_appli",
        password="vincentseum01",
        database="marsal15u_projet_tuteure"
    )

except ConnectionError:
    exit(0)

# preparing to process new documents

cursor = database.cursor()

sql = "SELECT num_CV, emplacement_fichier, num_offre FROM CV WHERE (contenu IS NULL OR contenu=\"\")"

# sort result in pandas Dataframe, udata stand for unprocessed_data

udata = pd.read_sql(sql, database)
udata.head()

# document extraction, ucontent stand for unprocessed content

ucontent = []
for index, row in udata.iterrows():
    filepath = CV_FOLDER + os.sep + row["emplacement_fichier"]
    if filepath.lower().endswith(".pdf"):
        ucontent.append(unidecode.unidecode(extract_text(filepath)).replace("\n", " "))
    elif filepath.lower().endswith(".docx"):
        ucontent.append(unidecode.unidecode(docx2txt.process(filepath)).replace("\n", " "))

udata["contenu"] = ucontent

# creating stemmer and stopwords for lemmatization

words = stopwords.words('french')
stemmer = SnowballStemmer('french')

# cleaning unprocessed data

udata['cleaned'] = udata['contenu'].apply(lambda x: " "
                                          .join([stemmer.stem(i)
                                                 for i in re
                                                .sub("[^a-zA-Z]", " ", x)
                                                .split() if i not in words]).lower())

# data has been cleaned : saving update in database

sql = "UPDATE CV SET contenu=%s WHERE num_CV = %s"

for index, row in udata.iterrows():
    values = (row["cleaned"], int(row["num_CV"]))
    cursor.execute(sql, values)

# importing cleaned data and which are classed

sql = "SELECT num_CV, contenu, score, num_classe FROM CV WHERE num_classe!=0"

cdata = pd.read_sql(sql, database)

x_train, x_test, y_train, y_test = train_test_split(cdata['contenu'], cdata.num_classe, test_size=0.1)

pipeline = Pipeline([('vect', TfidfVectorizer(ngram_range=(1, 3), sublinear_tf=True)),
                     ('chi', SelectKBest(chi2, k=10)),
                     ('clf', LinearSVC(C=1.0, penalty="l1", max_iter=20, dual=False))])

model = pipeline.fit(x_train, y_train)

vectorizer = model.named_steps['vect']
chi = model.named_steps['chi']
clf = model.named_steps['clf']

features_names = vectorizer.get_feature_names()
features_names = [features_names[i] for i in chi.get_support(indices=True)]
features_names = np.asarray(features_names)

target_names = ['1', '2', '3']

print("Accuracy score of algorithms : " + str(model.score(x_test, y_test)))

sql = "UPDATE CV SET num_classe=%s WHERE num_CV=%s"
for index, row in udata.iterrows():
    prediction = int(model.predict([row["cleaned"]]))
    values = (prediction, row["num_CV"])
    print("Prediction pour le CV d'id : " + str(row["num_CV"]) + " -> " + CV_CLASSE[prediction])
    cursor.execute(sql, values)

# getting all job offers

sql = "SELECT num_offre, contenu FROM OffreEmploi"
jddata = pd.read_sql(sql, database)

# comparing unproccessed data with associated JD in order to give a score

sql = "UPDATE CV SET score=%s WHERE num_CV=%s"

for index, row in udata.iterrows():
    # getting resume content and associated jd content in same dataframe
    mask = jddata.loc[jddata['num_offre'] == row['num_offre']]
    comparison_data = pd.DataFrame({"compare": [mask["contenu"][0], row["contenu"]]})

    # simple comparison with boW
    vectorizer = CountVectorizer()
    bagOfWords = vectorizer.fit_transform(comparison_data["compare"])

    # result
    score = round(cosine_similarity(bagOfWords)[0][1] * 100, 2)
    print("Score de l'element " + str(row["num_CV"]) + " : " + str(score) + "%")

    # saving in db
    values = (str(score), row["num_CV"])
    cursor.execute(sql, values)

# commiting all changes to db
database.commit()

database.close()
